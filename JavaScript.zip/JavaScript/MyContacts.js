var ary=[];
//var myary=[1,"Hussain","Valli","hussain2841@gmail.com","16-06-1995"];
function MyData(){
  var fn=document.forms["myForm"]["fname"].value;
    var ln=document.forms["myForm"]["lname"].value;
    var em=document.forms["myForm"]["email1"].value;
    var pass=document.forms["myForm"]["pwd"].value;
    var db=document.getElementById("dob").value;
    
    var emreg= /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if(fn=="" || ln=="")
    {
        alert(" Fname/Lname should not be empty");
       
        return false;
    }
   else if(fn.length<5 && fn.length<5)
    {
        alert("Fnam or Lname should be more or equal to 5 characters");
       
        return false;
    }
   else if(emreg.test(em)==false)
    {
        alert('invalid email address');
    }
    else if(pass.length<7)
    {
        alert("password contain atleast 8 characters");
        return false;
    }
   return true;
   var obj={fn,ln,em,pass,db};
   ary.push(obj);
       
   

    
   
        

}
