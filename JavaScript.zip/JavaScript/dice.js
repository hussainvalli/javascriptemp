var i=0;
var res=0;
var x=0;
var y=0;
function rollDice()
{
    res = Math.floor(Math.random() * ((6-1)+ 1) + 1);
    document.getElementById("diceresult").innerHTML = res;
   // if(res>0 || res==6)
     diceScore();
}
function diceScore()
{
    
    if(x>=100){
        document.getElementById("gameover1").innerHTML="you won the game!!!!!";
        document.getElementById("droll").disabled=true;
        
    }
    else if (y>=100){
           document.getElementById("gameover2").innerHTML="you won the game!!!!!!";
           document.getElementById("dhold").disabled=true;
    }   
    
   
   else if(i%2==0)
    {
        
        x=x+res;
        document.getElementById("fst").innerHTML=x;
        res==0;
        /*
        if(x!=6)
        i++
        */
       
    }
    else{ 
        y=y+res;
        document.getElementById("sec").innerHTML=y;
        res==0;
        /*if(y!=6)
            i++;
            */
        
    }
    
}
function holdGame()
{
            i++;
 
}
function resetGame(){
    x=0;
    y=0;
   
    document.getElementById("fst").innerHTML=x;
    document.getElementById("sec").innerHTML=y;
    document.getElementById("diceresult").innerHTML=0;
    document.getElementById("gameover1").innerHTML="";
    document.getElementById("gameover2").innerHTML="";
    document.getElementById("droll").disabled=false;
    document.getElementById("dhold").disabled=false;



}