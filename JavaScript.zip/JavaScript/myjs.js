function myFunc(name)
{
	return name;
}
var name=myFunc('hussain valli');
function sayHello() {
			alert("hello world");
		}
		/*function validation(){
			return "hi";
		}*/
		function changeText(id){
			id.innerHTML="oops!";
		}
function displayDate(){
		document.getElementById("date").innerHTML=Date();
	}
	function mouse_over()
	{
		alert("mouse over me");
	}
	function mouse_out(){
		alert("mouse outof me");
	}
	function submitfun()
	{
		alert("your form has been submitted");
	}
	function bgfield(c)
	{
		c.style.background="lightblue";
	}
	/*function getbyclass(){
		var x.value=document.getElementsByName("myname")[0].tagName;
		document.getElementById("getc").innerHTML=x;
	}
	function birds()
	{
		var n=document.getElementsByName("bird");
		var i;
		for (i=0;i<n.length;i++) {
			if(n[i].type=="checkbox")
			    n[i].checked=true;
		}
	}*/