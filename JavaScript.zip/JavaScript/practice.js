function foo() {
	// body...
	console.log("now i am calling anohter function");
	mall();
}
function mall()
{
	console.log("yes another called");
}
foo();
(function(){
	console.log("iife function");
}());
(function(arg1,arg2,arg3,arg4){
	console.log(typeof arg1);
	console.log(typeof arg2);
	console.log(typeof arg3);
	console.log(typeof arg4); 
	console.log('the sum of two numberss',arg2+arg1);
	console.log("the subtraction of two numberss",arg2-arg1);
	console.log("My name is: ",arg3+arg4);
	console.log("My name is: "+arg3+arg4);
	console.log("My name is: ",arg3+arg1);
	console.log("My name is: "+arg3+arg1);
	console.log("My name is: ",arg1+arg4);




})(10,20,'hussain','valli');
//------------------------------------------------------------


var obj={

	/*0:1,
	1:2,
	'name':'hussain',
	last:'valli',
	'':'empty string'*/
	/*id:0,
	name:'hussain'*/
};
//console.log(obj[0],obj[1],obj['name'],obj[last],obj['']);
//console.log(id,obj[name]);

//---------------------------------------------------

var arr=[1,2,3,,5];
console.log(arr);
var arr=new Array(1,'s',"hussain",1957);
console.log(arr);
//Array=String;
var SAry=[0,2,0,4];
console.log(SAry);
console.log(SAry instanceof Array);//--true
if(SAry instanceof Array)
	console.log("yes it is array instance");
console.log("length of array is:",SAry.length);
SAry[10]='agilecrm';
console.log(SAry);
console.log(SAry.length);
//-----------------------------------
var arr=[2,2,3,4];
Array.prototype.first=function(){
	return this[0];
}
console.log(arr.first());
//-----------------------------------
/* Array methods in javascript*/
//concat()
var student=['husain',"anil","shalem"];
var clg=['all','are',"rguktstudents"];
var result=student.concat(clg);
console.log(student);
console.log(clg);
console.log(result);
var vilage=['kadapa'];
console.log(student.concat(clg,vilage));
 
 //copyWithin()
 var fruits=["banana","orange","apple","mango"];
 console.log(fruits);
 console.log(fruits.copyWithin(0,3));

 //entries()

 var fruits=['banana','orange',"apple","mango"];
 var x=fruits.entries();
 console.log(x);
 console.log(fruits);

 var ary=['a','b','c'];
 var iterator1=ary.entries();
 console.log(iterator1.next().value);
 console.log(iterator1.next().value);


 //fill()
 var stud=["hi","my","name","is",9];
 stud.fill("hussain");//it will fill with hussain in 
 console.log(stud);
  

  //pop()

  var me=['shaik','hussain','valli'];
  console.log(me.pop());
  console.log(me);


//join()
var cmp=["my","agilecrm"];
console.log(cmp.join('.'));
console.log(cmp.join('-'));

//slice() 

var day=["today","isggd",'tuesday'];
var ck=day.slice(1,2);
console.log(ck);

var week=['sunday','mon','thursday'];
week.splice(2,1,'tuesday','wednesday')
console.log(week);

//shift()
 console.log(day.shift());
 console.log(day);


//unshift()
week.unshift('friday',"saturday");
console.log(week);
 //sort()

 var num=[8,88,5,78,6,1,0,8,89];
 num.sort(
 	function (a,b){
 		//return b-a //for descending order
 		return a-b //for ascending order
 	}
 );
 console.log(num);

 //---------------------

 //operators

 console.log(3+4*5);//23
 console.log(4*3**2);//4*(3^2)=36
 console.log(3**2);//9
 var a;
 var b;
 console.log(a=b=5);//true
 a=3;
 b=-2;
 console.log(a>0 && b>0);
 console.log(a>0 || b>0);
 console.log(!(a>0 || b>0));
console.log('hussain'&&'valli');
console.log('' && false);
console.log('hussain'|| 'valli');
console.log('' || false);
console.log(4*3/2);
console.log(11%3**2);
console.log(true+3);
console.log(false+1);
console.log(5+'hussain');
console.log('valli'+3);
console.log('hai'+false);
console.log(false+'hi');
console.log('hussain'+"valli");
console.log(true+'it is true');
console.log('it is true'+true);
console.log('hi'-3);
console.log(3-'hi');
console.log(1/2);
console.log(1.0/2);
console.log(1.0/2.0);

let sequ=[1,2,3];
sequ.push(4);
console.log(seq);


//------------------ Events  -----------

function birds()
	{
		var n=document.getElementsByName("bird");
		var i;
		for (i=0;i<n.length;i++) {
			if(n[i].type=="checkbox")
			    n[i].checked=true;
		}
	}
	function getbyclass(){
		var x.value=document.getElementsByName("myname")[0].tagName;
		document.getElementById("getc").innerHTML=x;
	}
	